# Trabalho de Mineração

- Dupla: Guilherme Brizzi e Mathias Eckert Recktenvald

## Informações
- O relatório está em report.pdf

- O código está na pasta /code/